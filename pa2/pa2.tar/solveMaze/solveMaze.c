#include "../graphutils.h" // header for functions to load and free adjacencyList
#include "../queue/queue.h" // header for queue

// A program to solve a maze that may contain cycles using BFS

int main ( int argc, char* argv[] ) {

    // First, read the query file to get the source and tgt nodes in the maze
    /* ... */
    FILE* q = fopen(argv[2], "r");
    graphNode_t st;
    graphNode_t tgt;
    fscanf(q, "%zu", &st);
    fscanf(q, "%zu", &tgt);
    fclose(q);
    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList = NULL;
    int graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);
    /* ... */

    // USE A QUEUE TO PERFORM BFS
    Queue queue = { .front=NULL, .back=NULL };

    // An array that keeps track of who is the parent node of each graph node we visit
    graphNode_t* parents = calloc( graphNodeCount, sizeof(graphNode_t) );
    for (size_t i=0; i<graphNodeCount; i++) {
        parents[i] = -1; // -1 indicates that a nodes is not yet visited
    }
    parents[adjacencyList[st].graphNode] = adjacencyList[st].graphNode;
    graphNode_t curr = adjacencyList[st].graphNode;

    while ( curr != tgt ) {

        // so long as we haven't found the tgt node yet, iterate through the adjacency list
        // add each neighbor that has not been visited yet (has no parents) to the queue of nodes to visit
        /* ... */
        AdjacencyListNode* neighbor = &adjacencyList[curr];
        while(neighbor){
            graphNode_t n = neighbor->graphNode;
            if(parents[n] == -1){
                enqueue(&queue, neighbor);
                parents[n] = curr;
            }
            neighbor = neighbor->next;
        }
        //dont forget to set to dequeue
        AdjacencyListNode* node = dequeue(&queue);
        curr = node ->graphNode;

        // Visit the next node at the front of the queue of nodes to visit
        /* ... */
    }
    int ct = tgt;
    do{
        printf("%d %ld \n",ct,parents[ct]);
        ct = parents[ct];
    }
    while(ct!=st);

    // Now that we've found the tgt graph node, use the parent array to print maze solution
    // Print the sequence of edges that takes us from the source to the tgt node
    /* ... */

    // free any queued graph nodes that we never visited because we already solved the maze
    while ( queue.front ) {
        QueueNode* trail = queue.front;
        queue.front = queue.front->next;
        free(trail);
        /* ... */
    }
    free (parents);
    freeAdjList ( graphNodeCount, adjacencyList );

    return EXIT_SUCCESS;
}
